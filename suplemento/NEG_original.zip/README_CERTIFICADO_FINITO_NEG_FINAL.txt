PACOTE FINAL — CERTIFICADO FINITO NEG

Conteúdo:
1. resultado_delannoy_negative_finite_certificate.txt
   - Relatório textual do certificado.
2. delannoy_negative_ladder_certificate.json
   - Certificado completo em JSON.
3. delannoy_negative_ladder_certificate.csv
   - Certificado em tabela CSV.
4. secao_artigo_certificado_finito_NEG.md
   - Seção pronta para inserir no artigo.
5. checkpoint_CERTIFICADO_FINITO_NEG_FINAL.txt
   - Resumo do checkpoint final.

Resultado principal:
- Total = 104448
- Total NEG = 13552
- Falhas basicas = 0
- Estados no certificado = 11858
- Estados conflitantes = 0
- Bad ladder end = 0
- STATUS CERTIFICADO FINITO NEG: PASS

Chave certificadora:
state_NEG = (pmod, s, a, q mod 256, u mod 128)

Conclusão:
A escada negativa é determinística pela chave acima nos casos testados,
e toda ladder termina em (-1,0). Assim, v2(S_neg)=w e o bloco negativo
da soma principal fica certificado.
