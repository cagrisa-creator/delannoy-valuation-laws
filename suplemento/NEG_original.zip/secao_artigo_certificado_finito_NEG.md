# Finite certificate for the negative block

This section records the finite certification of the negative block in the main-sum decomposition.

Let

\[
n=2^a u,\qquad u\ \text{odd},\qquad s=v_2(p-1),\qquad w=s+3a.
\]

For the principal truncated sum

\[
S_H=\sum_{1\le k\le H(a-1)} T_k,
\]

we split the terms according to their normalized valuation margin

\[
m(k)=v_2(T_k)-w.
\]

Thus,

\[
S^-=\sum_{m(k)<0}T_k,
\qquad
S^+=\sum_{m(k)\ge0}T_k.
\]

The difficult case is the negative-dominant regime, where the active count is even and the dominant contribution comes from \(S^-\). In this regime, the individual terms of \(S^-\) initially lie below the target valuation \(w\), but their cumulative layer sum cancels upward to valuation exactly \(w\).

The computational certificate uses the finite state

\[
\operatorname{state}_{NEG}
=
(p\bmod 8,\ s,\ a,\ q\bmod 256,\ u\bmod 128),
\]

where \(p=1+2^s q\) with \(q\) odd.

For every observed negative-dominant state, the certificate stores the corresponding cumulative ladder

\[
\operatorname{ladder}(\operatorname{state}_{NEG})
=
\bigl((m_1,\nu_1),\ldots,(m_r,\nu_r)\bigr),
\]

where \(m_i<0\) is a negative layer and \(\nu_i=v_2(C_i)-w\) is the normalized valuation of the cumulative partial layer sum.

The certificate verifies the following:

\[
\#\text{NEG cases}=13552,
\]

\[
\#\text{certified states}=11858,
\]

\[
\#\text{conflicting states}=0,
\]

and every certified ladder terminates at

\[
(-1,0).
\]

Therefore, for every certified negative-dominant case,

\[
v_2(S^-)=w,
\qquad
v_2(S^+)>w,
\]

and hence

\[
v_2(S_H)=w.
\]

Together with the nonnegative-dominant case, where the parity of the active terms gives \(S^+/2^w\) odd, this completes the finite certification of the main sum:

\[
v_2(S_H)=w=s+3a.
\]

Combining this with the tail bound

\[
v_2\left(\sum_{k>H(a-1)}T_k\right)>w,
\]

we obtain the certified valuation law

\[
v_2(D(pn)-D(n))=v_2(p-1)+3v_2(n)
\]

for all cases covered by the computational certificate.
